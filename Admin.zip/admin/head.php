<?php
session_start();
error_reporting(0);
	$con=mysqli_connect("localhost","root","","veggiebasket");
?>
<link rel="stylesheet" href="css/mdb.min.css" />